import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { LoginComponent } from './components/login/login.component';
import { ServiceComponent } from './components/service/service.component';
import { ContactComponent } from './components/contact/contact.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { RegistrationpageComponent } from './components/registrationpage/registrationpage.component';
import { StudentloginComponent } from './components/studentlogin/studentlogin.component';
import { AdminregistrationComponent } from './components/adminregistration/adminregistration.component';
import { AdminpageComponent } from './components/adminpage/adminpage.component';
import { StudentdetailsComponent } from './components/studentdetails/studentdetails.component';
import { StudentregistrationComponent } from './components/studentregistration/studentregistration.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';


@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    LoginComponent,
    ServiceComponent,
    ContactComponent,
    NavigationComponent,
    AboutusComponent,
   RegistrationpageComponent,
    StudentloginComponent,
    AdminregistrationComponent,
    AdminpageComponent,
    StudentdetailsComponent,
    StudentregistrationComponent,
    AdminloginComponent
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
