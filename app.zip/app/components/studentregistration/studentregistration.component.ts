import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
 

@Component({
  selector: 'app-studentregistration',
  templateUrl: './studentregistration.component.html',
  styleUrls: ['./studentregistration.component.css']
})
export class StudentregistrationComponent   {
  title = 'Student Registration Form';
  fname = new FormControl('', [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z]+$')]);
  lname = new FormControl('', [Validators.required, Validators.minLength(4)]);
  DOB = new FormControl('', Validators.required);
  emailid = new FormControl('', [Validators.required, Validators.minLength(15), Validators.maxLength(50), Validators.pattern('^[a-zA-Z0-9.@]+$')]);
  password = new FormControl('', [Validators.required, Validators.maxLength(8), Validators.pattern('^[0-9]+$')]);
  reenterpassword = new FormControl('', [Validators.required, Validators.maxLength(8)]);
  gender = new FormControl('', Validators.required);
  mobileNumber = new FormControl('', Validators.required);
  parentsNumber = new FormControl('', Validators.required);
  Qualification = new FormControl('', Validators.required);
  Address = new FormControl('', [Validators.required, Validators.minLength(25)]);
  profilepic = new FormControl('', Validators.required);
  formSubmitted: any;
passwordMismatch: any;

  constructor(private builder: FormBuilder, private router: Router) {}

  registrationForm: FormGroup = this.builder.group({
    fname: this.fname,
    lname: this.lname,
    DOB: this.DOB,
    emailid: this.emailid,
    password: this.password,
    reenterpassword: this.reenterpassword,
    gender: this.gender,
    mobileNumber: this.mobileNumber,
    parentsNumber: this.parentsNumber,
    Qualification: this.Qualification,
    Address: this.Address,
    profilepic: this.profilepic
  }, {
    validator: this.passwordsMatchValidator // Custom validator for password match
  });

  registrationFormData: any;
  confirmationMessage: boolean = false;

  onSubmitRegistrationForm(): void {
    console.log(this.registrationForm);
    this.registrationFormData = this.registrationForm.value;
    this.confirmationMessage = true;
  }
  
  resetForm(): void {
    this.registrationForm.reset();
    this.confirmationMessage=false;
  }

  studentlogin() {
    this.router.navigate(['/studentlogin']);
  }

  passwordsMatchValidator(group: FormGroup) {
    const passwordControl = group.get('password');
    const reenterPasswordControl = group.get('reenterpassword');
  
    if (passwordControl && reenterPasswordControl) {
      const passwordValue = passwordControl.value;
      const reenterPasswordValue = reenterPasswordControl.value;
  
      if (passwordValue !== reenterPasswordValue) {
        reenterPasswordControl.setErrors({ passwordMismatch: true });
      } else {
        reenterPasswordControl.setErrors(null);
      }
    }
  }
  login(){
    this.router.navigate(['/login']);
  }
}
