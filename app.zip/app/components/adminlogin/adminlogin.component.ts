import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  adminloginForm!: FormGroup;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.adminloginForm = this.formBuilder.group({
      rollNo: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    // Handle form submission here
    console.log(this.adminloginForm.value);
  }
}
