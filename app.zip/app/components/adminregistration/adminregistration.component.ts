import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-adminregistration',
  templateUrl: './adminregistration.component.html',
  styleUrls: ['./adminregistration.component.css']
})
export class AdminregistrationComponent implements OnInit {
  
  [x: string]: any;
  title = 'Admin Registration Page';
  fname=new FormControl('',[Validators.required,Validators.minLength(5)]);
  lname=new FormControl('',[Validators.required,Validators.minLength(4)]);
  emailid=new FormControl('',[Validators.required,Validators.minLength(15),Validators.pattern('^[a-zA-Z0-9.@]+$')]);
  password=new FormControl('',[Validators.required,Validators.maxLength(8),Validators.pattern('^[0-9]+$')]);
  reenterpassword=new FormControl('',[Validators.required,Validators.maxLength(8),Validators.pattern('^[0-9]+$')]);
  gender=new FormControl('',Validators.required);
  mobilenumber=new FormControl('',Validators.required);
  address=new FormControl('',Validators.required);
  constructor(private builder:FormBuilder,private router: Router){
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  registrationForm:FormGroup=this.builder.group({
   fname:this.fname,
   lname:this.lname,
   emailid:this.emailid,
   password:this.password,
   reenterpassword:this.reenterpassword,
   gender:this.gender,
   mobilenumber:this.mobilenumber,
   address:this.address
  } )
  registrationFormData:any
  confirmationMessage:boolean=false
  formSubmitted: boolean = false;
  onSubmitRegistrationForm():void{
    console.log(this.registrationForm)
    this.registrationFormData=this.registrationForm.value
    this.confirmationMessage=true;
    this.formSubmitted = true;
  }
  resetForm():void{
    this.registrationForm.reset();
    this.confirmationMessage=false;
}
adminpage(){
  this.router.navigate(['/adminpage']);
}


}
