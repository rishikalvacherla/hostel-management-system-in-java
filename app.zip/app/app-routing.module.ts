import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './components/homepage/homepage.component';
import { LoginComponent } from './components/login/login.component';
import { ServiceComponent } from './components/service/service.component';
import { ContactComponent } from './components/contact/contact.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { StudentloginComponent } from './components/studentlogin/studentlogin.component';
import { AdminregistrationComponent } from './components/adminregistration/adminregistration.component';
import { AdminpageComponent } from './components/adminpage/adminpage.component';
import { StudentdetailsComponent } from './components/studentdetails/studentdetails.component';
import { StudentregistrationComponent } from './components/studentregistration/studentregistration.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
const routes: Routes = [
  {path:'',component:NavigationComponent},
  {path:'home', component:HomepageComponent},
  {path:'login', component:LoginComponent},
  {path:'service', component:ServiceComponent},
  {path:'contact', component:ContactComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'studentlogin',component:StudentloginComponent},
  {path:'adminregistration',component:AdminregistrationComponent},
  {path:'adminpage',component:AdminpageComponent},
  {path:'studentdetails',component:StudentdetailsComponent},
  {path:'studentregistration',component:StudentregistrationComponent},
  {path:'adminlogin',component:AdminloginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
