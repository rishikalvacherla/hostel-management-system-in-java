package com.cjits.controller;

import com.cjits.entity.Student;
import com.cjits.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;
@RestController
@RequestMapping("/restapi/student")
public class StudentController {
    Logger logger= Logger.getLogger(this.getClass().getName());
    @Autowired
    private StudentService service;

    //1. Create REST API
    @PostMapping
    public ResponseEntity<Student> saveStudent(@RequestBody Student s){
        logger.warning("printing : "+s);
        return new ResponseEntity<Student>(service.saveStudent(s), HttpStatus.CREATED);
    }
    //2. Get REST API
    @GetMapping
    public List<Student> getAllStudents(){
        return service.getAllStudents();
    }
    //3. Get REST API by id
    @GetMapping("{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable("id") long studentId) throws RuntimeException{
        return new ResponseEntity<Student>(service.findStudentById(studentId),HttpStatus.OK);
    }
    //4. Update REST API
    @PutMapping("{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student s,@PathVariable("id") long studentId) throws RuntimeException{
        return new ResponseEntity<Student>(service.updateProduct(s, studentId), HttpStatus.OK);
    }
    //5. Delete REST API
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") long studentId){
        service.deleteStudent(studentId);
        return new ResponseEntity<String>("Student Deleted",HttpStatus.OK);
    }
}
