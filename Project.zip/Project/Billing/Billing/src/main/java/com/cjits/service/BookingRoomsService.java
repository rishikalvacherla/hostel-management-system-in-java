package com.cjits.service;

import com.cjits.entity.Billing;
import com.cjits.entity.BookingRooms;

import java.util.Date;
import java.util.List;

public interface BookingRoomsService {
    List<BookingRooms> getAllBookings();
    BookingRooms getBookingByBookingId(Long bookingId);
    BookingRooms getBookingByBookingDate(Date bookingDate);
    BookingRooms addBooking(BookingRooms bookingRooms);
    BookingRooms updateBooking(Long bookingId, BookingRooms bookingRooms);
    void deleteBooking(Long bookingId);
//    List<BookingRooms> getBookingByBookingId(Long bookingId);
}


