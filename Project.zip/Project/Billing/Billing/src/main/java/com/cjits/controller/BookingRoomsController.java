package com.cjits.controller;

import com.cjits.entity.Billing;
import com.cjits.entity.BookingRooms;
import com.cjits.service.BillingService;
import com.cjits.service.BookingRoomsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/restapi/bookings")
public class BookingRoomsController {

    @Autowired
    BookingRoomsService bookingRoomsService;

    @GetMapping
    public List<BookingRooms> getAllBookingRooms(){
        return bookingRoomsService.getAllBookings();
    }
    @GetMapping("{id}")
    public BookingRooms getByBookingId(@PathVariable("id") long bookingId) {
        return bookingRoomsService.getBookingByBookingId(bookingId);
    }
        @GetMapping("{bookingDate}")
        public BookingRooms getBillingByBookingDate(@PathVariable Date bookingDate){
            return bookingRoomsService.getBookingByBookingDate(bookingDate);
        }
    @PutMapping("{BookingId}")
    public BookingRooms updateBooking(@PathVariable Long bookingId,@RequestBody BookingRooms bookingRooms){
        return bookingRoomsService.updateBooking(bookingId,bookingRooms);
    }
    @PostMapping
    public BookingRooms addBookings(@RequestBody BookingRooms bookingRooms){
        return  bookingRoomsService.addBooking(bookingRooms);
    }
    @DeleteMapping("{BookingId}")
    public  void deleteBooking(@PathVariable Long bookingId){
        bookingRoomsService.deleteBooking(bookingId);
    }

}
