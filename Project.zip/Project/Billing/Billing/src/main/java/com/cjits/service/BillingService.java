package com.cjits.service;

import com.cjits.entity.Billing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public interface BillingService {
    List<Billing> getAllBillings();
    Billing getBillingByBillingId(Long billingId);
//    Billing getBillingByTransactionDate(Date transactionDate);
    Billing addBilling(Billing billing);
    Billing updateBilling(Long billingId, Billing billing);
    void deleteBilling(Long BillingId);
    List<Billing> getBillingByBookingId(Long bookingId);




}
