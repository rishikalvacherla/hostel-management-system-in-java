package com.cjits.service;

import com.cjits.entity.Billing;
import com.cjits.entity.BookingRooms;
import com.cjits.repository.BillingRepository;
import com.cjits.repository.BookingRoomsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BookingRoomsServiceImpl implements BookingRoomsService{
   @Autowired
   private BookingRoomsRepository bookingRoomsRepository;
    @Override
    public List<BookingRooms> getAllBookings() {
        return bookingRoomsRepository.findAll();
    }

    @Override
    public BookingRooms getBookingByBookingId(Long bookingId) {
        return bookingRoomsRepository.findAll(bookingId);
    }

    @Override
    public BookingRooms getBookingByBookingDate(Date bookingDate) {
        return bookingRoomsRepository.findByBookingDate(bookingDate);
    }

    @Override
    public BookingRooms addBooking(BookingRooms bookingRooms) {
        return bookingRoomsRepository.save(bookingRooms);
    }

    @Override
    public BookingRooms updateBooking(Long bookingId, BookingRooms bookingRooms) {
        BookingRooms bookings=getBookingByBookingId(bookingId);
        if(bookings!=null){
            bookingRooms.setBookingId(bookingId);
            return bookingRoomsRepository.save(bookingRooms);
        }
        return null;
    }

    @Override
    public void deleteBooking(Long bookingId) {
  bookingRoomsRepository.deleteById(bookingId);
    }
}
