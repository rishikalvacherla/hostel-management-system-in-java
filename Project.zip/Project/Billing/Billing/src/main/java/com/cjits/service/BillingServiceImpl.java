package com.cjits.service;

import com.cjits.entity.Billing;
import com.cjits.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BillingServiceImpl implements BillingService{
@Autowired
private BillingRepository billingRepository;
    @Override
    public List<Billing> getAllBillings() {
        return billingRepository.findAll();
    }

    @Override
    public Billing getBillingByBillingId(Long billingId) {
        return null;
//        return billingRepository.findAll(billingId);
    }


//    @Override
//    public Billing getBillingByTransactionDate(Date transactionDate) {
//        return billingRepository.findByTransactionDate(transactionDate);
//    }

    @Override
    public Billing addBilling(Billing billing) {
        return billingRepository.save(billing);
    }

    @Override
    public Billing updateBilling(Long billingId, Billing billing) {
        Billing billings=getBillingByBillingId(billingId);
        if(billings!=null){
            billing.setBillingId(billingId);
            return billingRepository.save(billing);
        }
        return null;
    }

    @Override
    public void deleteBilling(Long billingId) {
        billingRepository.deleteById(billingId);

    }

    @Override
    public List<Billing>
    getBillingByBookingId(Long bookingId) {
        return billingRepository.findByBookingId(bookingId);
    }
}

