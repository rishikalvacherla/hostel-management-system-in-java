package com.cjits.controller;

import com.cjits.entity.Billing;
import com.cjits.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/restapi/billing7")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @GetMapping
    public List<Billing> getAllBilling(){
        return billingService.getAllBillings();
    }
    @GetMapping("{id}")
    public Billing getBillingByBillingId(@PathVariable Long billingId){
        return billingService.getBillingByBillingId(billingId);
    }
//    @GetMapping("{transactionDate}")
//    public Billing getBillingByTransactionDate(@PathVariable Date transactionDate){
//        return billingService.getBillingByTransactionDate(transactionDate);
//    }
    @PostMapping
    public Billing addBilling(@RequestBody Billing billing){
        return billingService.addBilling(billing);
    }
    @PutMapping("{BillingId}")
    public Billing updateBilling(@PathVariable Long billingId,@RequestBody Billing billing){
        return billingService.updateBilling(billingId,billing);

    }
    @DeleteMapping("{BillingId}")
    public void deleteBilling(@PathVariable Long billingId) {
        billingService.deleteBilling(billingId);
    }
    @GetMapping("/byBookingRooms/{bookingId}")
    public List<Billing> getBillingByBookingId(@PathVariable Long bookingId){
        return billingService.getBillingByBookingId(bookingId);
    }


}
