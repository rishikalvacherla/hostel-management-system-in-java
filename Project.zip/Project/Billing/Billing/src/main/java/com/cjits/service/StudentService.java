package com.cjits.service;

import com.cjits.entity.Student;

import java.util.List;

public interface StudentService {
    Student saveStudent(Student student);

    List<Student> getAllStudents();

    Student findStudentById(long id) throws RuntimeException;

    Student updateProduct(Student s, long id) throws RuntimeException;

    void deleteStudent(long id);

}
