package com.cjits.entity;

import jakarta.persistence.*;
import org.springframework.util.IdGenerator;

import java.util.Date;
import java.util.List;

@Entity
@Table(name="bookings")
public class BookingRooms {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long bookingId;
        private Date bookingDate;
//           @ManyToOne
//    @JoinColumn(name = "room_id")
//    private Room room;

//    @ManyToOne
//    @JoinColumn(name = "student_id")
//    private Student student;

        public Long getBookingId() {
                return bookingId;
        }

        public void setBookingId(Long bookingId) {
                this.bookingId = bookingId;
        }

        public Date getBookingDate() {
                return bookingDate;
        }

        public void setBookingDate(Date bookingDate) {
                this.bookingDate = bookingDate;
        }


}

