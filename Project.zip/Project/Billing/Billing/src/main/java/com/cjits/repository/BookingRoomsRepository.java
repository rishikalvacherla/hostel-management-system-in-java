package com.cjits.repository;


import com.cjits.entity.BookingRooms;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.Date;
import java.util.List;

public interface BookingRoomsRepository extends JpaRepository<BookingRooms,Long> {
    
    BookingRooms findByBookingDate(Date bookingDate);

    BookingRooms findAll(Long bookingId);


//    List<BookingRooms> findByBookingDate(String bookingDate);
}
