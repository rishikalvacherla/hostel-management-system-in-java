package com.cjits.service;
import com.cjits.entity.Student;
import  com.cjits.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentRepository repo;

    @Override
    public Student saveStudent(Student student) {
        return repo.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
        return repo.findAll();
    }

    @Override
    public Student findStudentById(long id) throws RuntimeException {
        Optional<Student> prod = repo.findById(id);
        if (prod.isPresent()) {
            return prod.get();
        } else {
            throw new RuntimeException("Entered id" + id + "Not Found in repository");
        }
    }

    @Override
    public Student updateProduct(Student s, long id) throws RuntimeException {
        Student stud = repo.findById(id).get();
        if (stud.getId() != 0) {
            stud.setStudentFName(s.getStudentFName());
            stud.setStudentLName(s.getStudentLName());
            stud.setStudentGender(s.getStudentGender());
            stud.setStudentDOB(s.getStudentDOB());
            stud.setStudentemail(s.getStudentemail());
            stud.setStudentPassword(s.getStudentPassword());
            stud.setStudentReenterPassword(s.getStudentReenterPassword());
            stud.setStudentMobileNo(s.getStudentMobileNo());
            stud.setStudentParentName(s.getStudentParentName());
            stud.setStudentParentId(s.getStudentParentId());
            stud.setStudentQualification(s.getStudentQualification());
            stud.setStudentAddress(s.getStudentAddress());
        } else {
            throw new RuntimeException("Entered student id" + id + "Not found in repository");
        }
        repo.save(stud);
        return stud;
    }

    @Override
    public void deleteStudent(long id) {
        repo.deleteById(id);
    }
}