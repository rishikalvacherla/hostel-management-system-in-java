package com.cjits.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="billing10")
public class Billing {
    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long BillingId;

    private String amount;
    private String transactionDate;

    @ManyToOne
    @JoinColumn(name = "BookingId")
    private BookingRooms bookingRooms;

    @ManyToOne
    @JoinColumn(name = "studentId")
    private Student student;

    public long getBillingId() {
        return BillingId;
    }

    public void setBillingId(long billingId) {
        BillingId = billingId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public BookingRooms getBookingRooms() {
        return bookingRooms;
    }

    public void setBookingRooms(BookingRooms bookingRooms) {
        this.bookingRooms = bookingRooms;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }


}


//    public long getBillingId() {
//        return BillingId;
//    }
//
//    public void setBillingId(long billingId) {
//        this.BillingId = billingId;
//    }
//
////    public long getBookingId() {
////        return BookingId;
////    }
//
////    public void setBookingId(long bookingId) {
////        this.BookingId = bookingId;
////    }
//
//    public String getAmount() {
//        return amount;
//    }
//
//    public void setAmount(String amount) {
//        this.amount = amount;
//    }
//
//    public String getTransactionDate() {
//        return transactionDate;
//    }
//
//    public void setTransactionDate(String transactionDate) {
//        this.transactionDate = transactionDate;
//    }
////     public long getStudentId(){
////        return studentId;
////     }
////     public void setStudentId(long studentId){
////        this.studentId=studentId;
////     }
//    @Override
//    public String toString() {
//        return  BillingId +
////                ", " + BookingId +
//                ", " + amount +
//                ", " + transactionDate ;
////                ", " + studentId ;
//    }
//}
