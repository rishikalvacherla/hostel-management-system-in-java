package com.cjits.entity;

import jakarta.persistence.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;

@Entity
@Table(name ="student1")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(name = "student_fname")
    private String studentFName;
    @Column(name = "student_lname")
    private String studentLName;
    @Column(name = "student_gender")
    private String studentGender;
    @Column(name = "student_dob")
    private String studentDOB;
    @Column(name = "student_email")
    private String studentemail;
    @Column(name = "student_password")
    private String studentPassword;
    @Column(name = "student_reenterpassword")
    private String studentReenterPassword;
    @Column(name = "student_mobileno")
    private String studentMobileNo;
    @Column(name = "student_parentname")
    private String studentParentName;
    @Column(name = "student_parentid")
    private String studentParentId;
    @Column(name = "student_quali")
    private String studentQualification;
    @Column(name = "student_add")
    private String studentAddress;
//    @OneToMany(targetEntity = Billing.class,cascade = CascadeType.ALL)
//    @JoinColumn(name="cp_fk",referencedColumnName = "id")
//    private List<Billing> billing;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStudentFName() {
        return studentFName;
    }

    public void setStudentFName(String studentFName) {
        this.studentFName = studentFName;
    }

    public String getStudentLName() {
        return studentLName;
    }

    public void setStudentLName(String studentLName) {
        this.studentLName = studentLName;
    }

    public String getStudentGender() {
        return studentGender;
    }

    public void setStudentGender(String studentGender) {
        this.studentGender = studentGender;
    }

    public String getStudentDOB() {
        return studentDOB;
    }

    public void setStudentDOB(String studentDOB) {
        this.studentDOB = studentDOB;
    }

    public String getStudentemail() {
        return studentemail;
    }

    public void setStudentemail(String studentemail) {
        this.studentemail = studentemail;
    }

    public String getStudentPassword() {
        return studentPassword;
    }

    public void setStudentPassword(String studentPassword) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        this.studentPassword = passwordEncoder.encode(studentPassword);
    }

    public String getStudentReenterPassword() {
        return studentReenterPassword;
    }

    public void setStudentReenterPassword(String studentReenterPassword) {
        BCryptPasswordEncoder ReenterpasswordEncoder = new BCryptPasswordEncoder();
        this.studentReenterPassword = ReenterpasswordEncoder.encode(studentReenterPassword);
    }

    public String getStudentMobileNo() {
        return studentMobileNo;
    }

    public void setStudentMobileNo(String studentMobileNo) {
        this.studentMobileNo = studentMobileNo;
    }

    public String getStudentParentName() {
        return studentParentName;
    }

    public void setStudentParentName(String studentParentName) {
        this.studentParentName = studentParentName;
    }

    public String getStudentParentId() {
        return studentParentId;
    }

    public void setStudentParentId(String studentParentId) {
        this.studentParentId = studentParentId;
    }

    public String getStudentQualification() {
        return studentQualification;
    }

    public void setStudentQualification(String studentQualification) {
        this.studentQualification = studentQualification;
    }

    public String getStudentAddress() {
        return studentAddress;
    }

    public void setStudentAddress(String studentAddress) {
        this.studentAddress = studentAddress;
    }

    public Student() {
    }

    @Override
    public String toString() {
        return "Student" +
                " " + id +
                "," + studentFName +
                "," + studentLName +
                "," + studentGender +
                "," + studentDOB +
                "," + studentemail +
                "," + studentPassword +
                "," + studentReenterPassword +
                "," + studentMobileNo +
                "," + studentParentName +
                "," + studentParentId +
                "," + studentQualification +
                "," + studentAddress;
    }
}