package com.cjits.repository;

import com.cjits.entity.Billing;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;
//@Transactional
public interface BillingRepository extends JpaRepository <Billing,Long> {
    

//    Billing findByTransactionDate(Date transactionDate);

    List<Billing> findByBookingId(Long bookingId);


//    Billing findAll(Long billingId);
}
