package com.cjits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomAndHostelApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomAndHostelApplication.class, args);
	}

}
