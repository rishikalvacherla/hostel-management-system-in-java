package com.cjits.service;

import com.cjits.entity.Hostel;
import com.cjits.repository.HostelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class HostelServiceImpl implements HostelService {

    @Autowired
    private HostelRepository hostelRepository;

    @Override
    public List<Hostel> getAllHostels() {
        return hostelRepository.findAll();
    }

    @Override
    public Hostel getHostelById(Long id) {
        return hostelRepository.findById(id).orElse(null);
    }

    @Override
    public Hostel addHostel(Hostel hostel) {
        return hostelRepository.save(hostel);
    }

    @Override
    public Hostel updateHostel(Long id, Hostel hostel) {
        Hostel existingHostel = getHostelById(id);
        if (existingHostel != null) {
            hostel.setHostelId(id);
            return hostelRepository.save(hostel);
        }
        return null;
    }

    @Override
    public void deleteHostel(Long id) {
        hostelRepository.deleteById(id);
    }

    // You can add additional methods as needed

}
