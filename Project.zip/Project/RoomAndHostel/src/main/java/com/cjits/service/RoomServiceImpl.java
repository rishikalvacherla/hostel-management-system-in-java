package com.cjits.service;

import com.cjits.entity.Room;
import com.cjits.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Override
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    @Override
    public Room getRoomById(Long id) {
        return roomRepository.findById(id).orElse(null);
    }

    @Override
    public Room addRoom(Room room) {
        return roomRepository.save(room);
    }

    @Override
    public Room updateRoom(Long id, Room room) {
        Room existingRoom = getRoomById(id);
        if (existingRoom != null) {
            room.setRoomId(id);
            return roomRepository.save(room);
        }
        return null;
    }

    @Override
    public String deleteRoom(Long id) {
        roomRepository.deleteById(id);
        return null;
    }

    @Override
    public List<Room> getRoomsByHostelHostelId(Long hostelId) {
        return roomRepository.findByHostelHostelId(hostelId);
    }


    // You can add additional methods as needed

}
