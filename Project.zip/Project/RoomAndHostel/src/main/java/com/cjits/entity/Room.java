package com.cjits.entity;

import jakarta.persistence.*;

@Entity
@Table(name ="rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roomId;

    private String roomType;
    private String roomStatus;
    private String roomNumber;
    private int capacity;
    private double price;

    @ManyToOne
    @JoinColumn(name = "hostel_id")
    private Hostel hostel;

    // Constructors, getters, and setters

    public Room(Long roomId, String roomType, String roomStatus, String roomNumber, int capacity, double price, Hostel hostel) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.roomStatus = roomStatus;
        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.price = price;
        this.hostel = hostel;
    }

    public Room() {}

    // Getters and setters

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getRoomStatus() {
        return roomStatus;
    }

    public void setRoomStatus(String roomStatus) {
        this.roomStatus = roomStatus;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Hostel getHostel() {
        return hostel;
    }

    public void setHostel(Hostel hostel) {
        this.hostel = hostel;
    }
}
