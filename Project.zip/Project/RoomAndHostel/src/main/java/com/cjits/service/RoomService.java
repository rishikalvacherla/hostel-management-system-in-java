package com.cjits.service;

import com.cjits.entity.Room;

import java.util.List;

public interface RoomService {

        List<Room> getAllRooms();
        Room getRoomById(Long id);
        Room addRoom(Room room);
        Room updateRoom(Long id, Room room);
        String deleteRoom(Long id);



        // You can add additional methods as needed
        List<Room> getRoomsByHostelHostelId(Long hostelId);
}
