package com.cjits.service;

import com.cjits.entity.Hostel;
import java.util.List;

public interface HostelService {

    List<Hostel> getAllHostels();
    Hostel getHostelById(Long id);
    Hostel addHostel(Hostel hostel);
    Hostel updateHostel(Long id, Hostel hostel);
    void deleteHostel(Long id);
}
