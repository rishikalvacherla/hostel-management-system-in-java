
package com.cjits.controller;

import com.cjits.entity.User;
import com.cjits.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User newUser = userService.register(user);
        return new ResponseEntity<>(newUser, HttpStatus.CREATED);
    }

//    @PostMapping("/login")
//    public ResponseEntity<User> loginUser(@RequestParam String username, @RequestParam String password) {
//        User user = userService.login(username, password);
//        return new ResponseEntity<>(user, HttpStatus.OK);
//    }
@PostMapping("/login")
public ResponseEntity<User> loginUser(@RequestParam String username, @RequestParam String password) {
    User user = userService.login(username, password);
    if (user != null) {
        return new ResponseEntity<>(user, HttpStatus.OK);
    } else {
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }
}

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestParam String email) {
        userService.forgotPassword(email);
        return new ResponseEntity<>("Reset password email sent", HttpStatus.OK);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logoutUser(@RequestParam String username) {
        userService.logout(username);
        return new ResponseEntity<>("User logged out", HttpStatus.OK);
    }

    @GetMapping("/role/{role}")
    public ResponseEntity<User> getUserByRole(@PathVariable String role) {
        User user = userService.getByRole(role);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
}