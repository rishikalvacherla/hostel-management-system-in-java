package com.cjits.controller;

import com.cjits.entity.Hostel;
import com.cjits.service.HostelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/hostels")
public class HostelController {

    @Autowired
    private HostelService hostelRepository;

    @GetMapping
    public List<Hostel> getAllHostels() {
        return hostelRepository.getAllHostels();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Hostel> getHostelById(@PathVariable Long id) {
        Optional<Hostel> optionalHostel = hostelRepository.getHostelById(id);
        return optionalHostel.map(hostel -> new ResponseEntity<>(hostel, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Hostel> createHostel(@RequestBody Hostel hostel) {
        Hostel createdHostel = hostelRepository.createHostel(hostel);
        return new ResponseEntity<>(createdHostel, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Hostel> updateHostel(@PathVariable Long id, @RequestBody Hostel hostel) {
        Hostel updatedHostel = hostelRepository.updateHostel(id, hostel);
        if (updatedHostel != null) {
            return new ResponseEntity<>(updatedHostel, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteHostel(@PathVariable Long id) {
        boolean deleted = Boolean.parseBoolean(hostelRepository.deleteHostel(id));
        if (deleted) {
            return new ResponseEntity<>("Deleted hostel with id: " + id, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Hostel not found with id: " + id, HttpStatus.NOT_FOUND);
        }
    }


}
