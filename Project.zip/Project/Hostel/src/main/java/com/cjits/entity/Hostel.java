package com.cjits.entity;

import jakarta.persistence.*;


@Entity
@Table(name ="hostel")
public class Hostel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long hostelId;

    private String hostelName;
    private String hostelType;



    // Constructors, getters, and setters

    public Hostel(Long hostelId, String hostelName, String hostelType) {
        this.hostelId = hostelId;
        this.hostelName = hostelName;
        this.hostelType = hostelType;
    }

    public Hostel() {

    }

    @Override
    public String toString() {
        return "Hostel{" +
                "hostelId=" + hostelId +
                ", hostelName='" + hostelName + '\'' +
                ", hostelType='" + hostelType +
                '}';
    }

//    private String hostelName;
//    private String hostelType;

    // Getter and setter for hostelName
    public String getHostelName() {
        return hostelName;
    }

    public void setHostelName(String hostelName) {
        this.hostelName = hostelName;
    }

    // Getter and setter for hostelType
    public String getHostelType() {
        return hostelType;
    }

    public void setHostelType(String hostelType) {
        this.hostelType = hostelType;
    }
}
