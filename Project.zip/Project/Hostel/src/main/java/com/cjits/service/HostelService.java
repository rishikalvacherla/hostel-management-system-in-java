package com.cjits.service;

import com.cjits.entity.Hostel;

import java.util.List;
import java.util.Optional;

public interface HostelService {
    List<Hostel> getAllHostels();
    Optional<Hostel> getHostelById(Long id);

    Hostel createHostel(Hostel hostel);

    Hostel updateHostel(Long id, Hostel HostelDetails);

    String deleteHostel(Long id);
    Hostel save(Hostel hostel);
}
