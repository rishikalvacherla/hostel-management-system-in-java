
package com.cjits.service;

import com.cjits.entity.Hostel;
import com.cjits.repository.HostelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HostelServiceImpl implements HostelService {

    @Autowired
    private HostelRepository hostelRepository;

//    @Override
//    public List<Hostel> getAllHostel() {
//        return hostelRepository.findAll();
//    }

    @Override
    public Optional<Hostel> getHostelById(Long id) {
        Optional<Hostel> hostel = hostelRepository.findById(id);
        return Optional.ofNullable(hostel.orElse(null));
    }

    @Override
    public Hostel createHostel(Hostel hostel) {
        return hostelRepository.save(hostel);
    }

    @Override
    public Hostel updateHostel(Long id, Hostel hostelDetails) {
        Optional<Hostel> optionalHostel = hostelRepository.findById(id);
        if (optionalHostel.isPresent()) {
            Hostel hostel = optionalHostel.get();
            hostel.setHostelName(hostelDetails.getHostelName());
            hostel.setHostelType(hostelDetails.getHostelType());
            // Set other fields as needed
            return hostelRepository.save(hostel);
        } else {
            return null; // Handle not found
        }
    }

    @Override
    public String deleteHostel(Long id) {
        Optional<Hostel> optionalHostel = hostelRepository.findById(id);
        if (optionalHostel.isPresent()) {
            hostelRepository.deleteById(id);
            return "Hostel with ID " + id + " deleted successfully";
        } else {
            return "Hostel with ID " + id + " not found";
        }
    }

    @Override
    public List<Hostel> getAllHostels() {
        return null;
    }


    @Override
    public Hostel save(Hostel hostel) {
        return null;
    }

}
