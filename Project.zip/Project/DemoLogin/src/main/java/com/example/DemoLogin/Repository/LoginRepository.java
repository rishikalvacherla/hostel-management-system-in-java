package com.example.DemoLogin.Repository;

import com.example.DemoLogin.entity.Login;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginRepository extends JpaRepository<Login, Long> {
    Login findByEmailAndPassword(String email, String password);
}
