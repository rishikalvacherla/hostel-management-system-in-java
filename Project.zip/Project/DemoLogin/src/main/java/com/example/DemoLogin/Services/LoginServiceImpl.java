package com.example.DemoLogin.Services;
import com.example.DemoLogin.Repository.LoginRepository;
import com.example.DemoLogin.entity.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginRepository loginRepository;

    @Override
    public List<Login> getAllLogins() {
        return loginRepository.findAll();
    }

    @Override
    public Login getLoginById(Long id) {
        return loginRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Login not found with id: " + id));
    }

    @Override
    public Login createLogin(Login login) {
        return loginRepository.save(login);
    }

    @Override
    public Login updateLogin(Long id, Login loginDetails) {
        Login login = loginRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Login not found with id: " + id));

        login.setEmail(loginDetails.getEmail());
        login.setPassword(loginDetails.getPassword());

        return loginRepository.save(login);
    }

    @Override
    public String deleteLogin(Long id) {
        loginRepository.deleteById(id);
        return "Deleted login with id: " + id;
    }
}
