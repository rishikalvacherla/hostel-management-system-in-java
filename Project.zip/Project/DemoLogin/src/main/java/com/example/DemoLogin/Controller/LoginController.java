package com.example.DemoLogin.Controller;

import com.example.DemoLogin.Repository.LoginRepository;
import com.example.DemoLogin.Services.LoginServiceImpl;
import com.example.DemoLogin.entity.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/login")
public class LoginController {

    @Autowired
    private LoginRepository loginRepository;
    @Autowired
    private LoginServiceImpl service;
    private Login login;

    @GetMapping
    public List<Login> getAllLogins() {
        return loginRepository.findAll();
    }
@GetMapping("/{id}")
public ResponseEntity<?> getLoginById(@PathVariable Long id) {
    Optional<Login> optionalLogin = loginRepository.findById(id);
    if (optionalLogin.isPresent()) {
        Login login = optionalLogin.get();
        // BCryptPasswordEncoder passwordEncoder=new BCryptPasswordEncoder();
        // login.setPassword(passwordEncoder.encode(login.getPassword()));
        return ResponseEntity.ok(login);
    } else {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Login ID " + id + " not found");
    }
}
@PostMapping("/create")
public ResponseEntity<String> createLogin(@RequestBody Login login) {
    Login createdLogin = loginRepository.save(login);
    if (createdLogin != null) {
        return ResponseEntity.status(HttpStatus.CREATED).body("Login added successfully");
    } else {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add login");
    }
}


    @PutMapping("/{id}")
    public Login updateLogin(@PathVariable Long id, @RequestBody Login loginDetails) {
        Login login = loginRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Login not found with id: " + id));

//        login.setEmail(loginDetails.getEmail()); // Update to use email field
        login.setPassword(loginDetails.getPassword());

        return loginRepository.save(login);
    }
    @DeleteMapping("/{id}")
    public String deleteLogin(@PathVariable Long id) {
        loginRepository.deleteById(id);
        return "Deleted login with id: " + id;
    }

}
