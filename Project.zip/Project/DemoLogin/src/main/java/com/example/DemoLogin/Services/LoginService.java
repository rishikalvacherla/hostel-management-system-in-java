package com.example.DemoLogin.Services;

import com.example.DemoLogin.entity.Login;

import java.util.List;

public interface LoginService {
    List<Login> getAllLogins();
    Login getLoginById(Long id);

    Login createLogin(Login login);
    Login updateLogin(Long id, Login loginDetails);
    String deleteLogin(Long id);
}
